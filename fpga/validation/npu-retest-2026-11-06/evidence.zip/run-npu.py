from pathlib import Path
import subprocess,sys,json,hashlib
root=Path.cwd();out=root/'fpga/build/npu-retest';bin=Path('D:/GitHub/tab5-tang-primer20k-carrier/fpga/build/windows-tools/oss-cad-suite/bin');report={'hardware_access':False,'passed':False,'suites':[]}
for name,gen,top in [('mac','generate_vectors.py','tb_int8_mac_lane'),('requant','generate_requant_vectors.py','tb_int8_requantize'),('dot','generate_dot_vectors.py','tb_int8_dot_job')]:
 log=[]
 commands=[[sys.executable,str(root/'fpga/npu/tests'/gen),'--output',str(out)],[str(bin/'iverilog.exe'),'-g2012','-Wall','-s',top,'-o',str(out/(name+'.vvp')),*map(str,(root/'fpga/npu/rtl').glob('*.v')),str(out/(top+'.v'))],[str(bin/'vvp.exe'),str(out/(name+'.vvp'))]]
 for c in commands:
  p=subprocess.run(c,capture_output=True,text=True,timeout=180);log.append(p.stdout+p.stderr);assert p.returncode==0,log[-1]
 (out/(name+'.log')).write_text('\n'.join(log));report['suites'].append({'name':name,'passed':True,'output':log[-1]});print(name,log[-1],flush=True)
report['passed']=True
report['source_sha256']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'fpga/npu/rtl').glob('*.v')}
(out/'npu-rtl.json').write_text(json.dumps(report,indent=2))
