from pathlib import Path
import sys
sys.path.insert(0,'D:/github/airpocket-soundman/tab5-gpu-review-20261106/tools')
from gpu_lab import Client
from compare_dock_demo import wait_idle
import qualify_demo_profile as q
c=Client('COM4',timeout=30)
try:
 c.call('stop');wait_idle(c,timeout=20);c.configure(mode='CPU',polygon_demo='cubes',running=False)
finally:c.close()
q.CASES=[x for x in q.CASES if x['scene']!=1 and x['load']==2 and x['frame']==0]
assert len(q.CASES)==7
raise SystemExit(q.main(['--port','COM4','--expected-elf-sha','4d9b6dd2c9dd232e0b50d8899267d67e5140bf9674a3cc993f7b4be5dd707ef6','--output',str(Path(__file__).resolve().parent/'depth16-other7'),'--fast-pack','off','--polygon-queue','on','--tx-hz','20000000','--execute']))
