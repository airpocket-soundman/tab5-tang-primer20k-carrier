from pathlib import Path
import argparse,sys,json,hashlib,subprocess,re
repo=Path('D:/github/airpocket-soundman/tab5-gpu-review-20261106');sys.path.insert(0,str(repo/'tools'))
from gpu_lab import Client
from compare_all_scenes import verify_target
from compare_dock_demo import wait_idle
from qualify_demo_profile import info_guard,profile
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--fs',type=Path,required=True);p.add_argument('--usercode',required=True);p.add_argument('--cpu',action='store_true');a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=False)
r={'passed':False,'rows':[],'scope':'Robot LIGHT integer,24warmup+120measured; fixed hostELF/TX20/RX16/bytewise/queueON/RXoptsOFF; software presentation pipeline, not LCD FPS'}
def save():(a.output/'result.json').write_text(json.dumps(r,indent=2)+'\n')
c=None
try:
 r['target']=verify_target('COM4');r['fs_path']=str(a.fs);r['fs_sha256']=hashlib.sha256(a.fs.read_bytes()).hexdigest()
 c=Client('COM4',timeout=30);r['info']=c.call('info');info_guard(r['info'],'4d9b6dd2c9dd232e0b50d8899267d67e5140bf9674a3cc993f7b4be5dd707ef6');boot=r['info']['boot_id']
 c.call('stop');wait_idle(c,boot,20);s=c.call('link',action='disarm');profile(s,False,boot,fast_pack=False,tx_hz=20000000)
 assert s['polygon_queue_enabled'] and not s['dma_opt_zero_copy_view'] and not s['dma_opt_reuse_stream_crc']
 prog=Path('D:/tools/gowin-programmer-1.9.12.04/Programmer/bin/programmer_cli.exe')
 for op,label,expected in [(73,'usercode',int(a.usercode,16)),(74,'status',0x6020)]:
  t=subprocess.run([str(prog),'--device','GW2A-18C','--operation_index',str(op),'--cable-index','1','--frequency','2.5MHz'],cwd=prog.parent,capture_output=True,text=True)
  (a.output/(label+'.log')).write_text(t.stdout+t.stderr);r[label+'_readback']=t.stdout+t.stderr
  match=re.search(('User Code' if op==73 else 'Status Code')+r' is:\s*0x([0-9A-Fa-f]+)',t.stdout)
  assert match and int(match[1],16)==expected,(label,t.stdout,t.stderr)
 before=c.call('link',action='arm');profile(before,True,boot,fast_pack=False,tx_hz=20000000);errors=before['link_errors'];r['before']=before;save()
 for mode in (['CPU','FPGA'] if a.cpu else ['FPGA']):
  c.configure(mode=mode,raster='integer_g0',scene=1,load=0,frame=0,polygon_demo='robot',running=False)
  rows=c.measure(timeout=300);assert len(rows)==1 and rows[0]['frames']==120 and rows[0]['mode']==mode and rows[0]['polygon_demo']=='robot'
  r['rows']+=rows;save();print(mode,rows,flush=True)
 c.call('stop');wait_idle(c,boot,20)
 after=c.call('link',action='status');profile(after,True,boot,fast_pack=False,tx_hz=20000000);assert after['link_errors']==errors and after['link_error']=='none'
 r['after']=after;r['passed']=True
except Exception as e:r['error']=repr(e)
finally:
 if c:
  try:c.call('stop');wait_idle(c,timeout=20);r['final_disarm']=c.call('link',action='disarm')
  except Exception as e:r['cleanup_error']=repr(e);r['passed']=False
  c.close()
 save()
print('PASS',r['passed'],r.get('error'),flush=True)
sys.exit(0 if r['passed']else 1)
