import pathlib,re,html,json,hashlib,zipfile,collections
root=pathlib.Path('D:/github/airpocket-soundman/tab5-carrier-review-20261106');out=pathlib.Path('D:/esp/images/depth16-20261106');pnr=root/'fpga/build/depth16-v1/depth16/impl/pnr';snap=root/'fpga/build/depth16-v1/source_snapshot';z=zipfile.ZipFile(root/'fpga/validation/duplex-register-2026-11-06/candidate.zip');manifest=json.loads((root/'fpga/validation/duplex-register-2026-11-06/manifest.json').read_text(encoding='utf-8'));audit=json.loads(z.read('fpga/build/duplex-register-v1/audit.json'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def clean(s):return re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]+>',' ',s))).strip()
def rows(s):return [[clean(c)for c in re.findall(r'<t[dh][^>]*>(.*?)</t[dh]>',r,re.S)]for r in re.findall(r'<tr[^>]*>(.*?)</tr>',s,re.S)]
tr=(pnr/'depth16_tr_content.html').read_text(encoding='utf-8');table=rows(tr);counts={r[0]:int(r[1])for r in table if len(r)==2 and r[0].startswith('Numbers of')}
clocks=[]
section=tr.split('name="Clock_Report"',1)[1].split('name="Max_Frequency_Report"',1)[0]
for r in rows(section):
 if r and r[0].isdigit():clocks.append(r)
fmax=[]
for r in rows(tr.split('name="Max_Frequency_Report"',1)[1].split('name="Total_Negative_Slack_Report"',1)[0]):
 if r and r[0].isdigit():fmax.append(r)
minima={}
for typ in ['Setup','Hold','Recovery','Removal']:
 a=tr.find('name="'+typ+'_Slack_Table');following={'Setup':'Hold','Hold':'Recovery','Recovery':'Removal'}.get(typ);b=tr.find('name="'+following+'_Slack_Table',a+15) if following else tr.find('name="Timing_Exceptions_Report',a+15);section=tr[a:b if b>=0 else None]
 paths=[r for r in rows(section)if len(r)>=9 and r[0].isdigit() and re.fullmatch(r'-?\d+\.\d+',r[1])]
 if paths:minima[typ]=min(paths,key=lambda r:float(r[1]))
compare=[]
for name,expected in audit['source_snapshot_sha256'].items():
 p=snap/pathlib.Path(name.replace('\\','/'));actual=sha(p.read_bytes());compare.append(dict(file=name,baseline=expected,current=actual,same=actual==expected))
# Physical constraints and pin-report rows, explicit LOC matching.
cst=(snap/'constraints/dock/tab5_dock_link_v0.cst').read_text(encoding='utf-8');locations=dict(re.findall(r'IO_LOC\s+"([^"]+)"\s+([^;\s]+)',cst))
pinrows=rows((pnr/'depth16.pin.html').read_text(encoding='utf-8'));pins=[]
for signal,loc in locations.items():
 matches=[r for r in pinrows if r and r[0]==signal]
 pins.append(dict(signal=signal,loc=loc,rows=matches,matched=any(any(c.split('/')[0]==loc for c in r)for r in matches)))
log=(out/'build-depth16.log').read_text(encoding='utf-8');base_log=z.read('fpga/build/duplex-register-v1-build.log').decode()
def warns(s):return [re.sub(r'"[^"\n]*source_snapshot[\\/]', '"',l.strip())for l in s.splitlines()if re.search(r'WARN\s*\(',l)]
nw,bw=warns(log),warns(base_log);extra=list((collections.Counter(nw)-collections.Counter(bw)).elements())
rpt=(pnr/'depth16.rpt.txt').read_text(encoding='utf-8');resource={}
for key in ['Logic','Register','BSRAM','DSP','I/O Port']:
 m=re.search(r'^\s*'+re.escape(key)+r'\s*\|\s*([^|\n]+)',rpt,re.M);resource[key]=m.group(1).strip()if m else None
fs=(pnr/'depth16.fs').read_bytes();header=fs[:1500].decode();user=re.search(r'UserCode:\s*(\S+)',header).group(1)
result=dict(hardware_access=False,build_completed=all(x in log for x in ['GowinSynthesis finish','Placement and routing completed','Bitstream generation completed','DEPTH16_CANDIDATE_RETURNED']),fs_sha256=sha(fs),usercode=user,part='GW2A-LV18PG256C8/I7',sta_counts=counts,clocks=clocks,fmax=fmax,minima=minima,resources=resource,source_snapshot=compare,changed_sources=[r['file']for r in compare if not r['same']],nondepth_same=sum(r['same']for r in compare),pins=pins,all_cst_locations_match=all(p['matched']for p in pins),warnings_current=nw,warnings_extra_vs7375=extra,errors=[l for l in log.splitlines()if re.search(r'\bERROR\b',l)],baseline_zip_sha256=sha((root/'fpga/validation/duplex-register-2026-11-06/candidate.zip').read_bytes()),baseline_zip_hash_matches=sha((root/'fpga/validation/duplex-register-2026-11-06/candidate.zip').read_bytes())==manifest['zip_sha256'],baseline_resources_limitation=None,baseline_pnr_primitive_counts=dict(collections.Counter(re.findall(r'^\s*(LUT\d|DFF\w*|ALU|DPB|SP|MULT\w*)\s+',z.read('fpga/build/duplex-register-v1/duplex_register/impl/pnr/duplex_register.vo').decode(),re.M))),source_hash=sha((snap/'gfx/rtl/triangle_depth.v').read_bytes()))
result['offline_checks_pass']=result['build_completed'] and user.lower()=='0x000016d0' and counts.get('Numbers of Setup Violated Endpoints')==0 and counts.get('Numbers of Hold Violated Endpoints')==0 and result['nondepth_same']==17 and len(result['changed_sources'])==1 and result['all_cst_locations_match'] and not result['errors']
(out/'build-review.json').write_text(json.dumps(result,indent=2));(out/'build-review.log').write_text(json.dumps({k:result[k]for k in ['offline_checks_pass','usercode','fs_sha256','sta_counts','fmax','minima','resources','changed_sources','nondepth_same','all_cst_locations_match','warnings_extra_vs7375','errors']},indent=2));print((out/'build-review.log').read_text(encoding='utf-8'))

# Baseline aggregate report is stored at archive root, not under the PNR path.
qualified_path=root/'fpga/validation/communication-qualified-2026-11-06/qualified-gfx-7375.zip'
qualified=zipfile.ZipFile(qualified_path)
baseline_rpt=qualified.read('duplex_register.rpt.txt').decode().replace('\r\r\n','\n').replace('\r\n','\n')
baseline_resources={}
for key in ['Logic','Register','BSRAM','DSP','I/O Port']:
 m=re.search(r'^\s*'+re.escape(key)+r'\s*\|\s*([^|\n]+)',baseline_rpt,re.M)
 baseline_resources[key]=m.group(1).strip() if m else None
result['baseline_resources']=baseline_resources
result['baseline_resource_report']={'archive_member':'duplex_register.rpt.txt','sha256_raw':sha(qualified.read('duplex_register.rpt.txt')),'archive_path':str(qualified_path),'archive_sha256':sha(qualified_path.read_bytes()),'normalization':'CRCRLF and CRLF to LF for text parsing only'}
result['resource_delta_used']={k:float(result['resources'][k].split('/')[0])-float(v.split('/')[0]) for k,v in baseline_resources.items() if v and result['resources'][k]}
result['baseline_resources_limitation']=None
result['baseline_bundles_same_fs']={'candidate_bundle_fs_sha256':sha(z.read('fpga/build/duplex-register-v1/duplex_register/impl/pnr/duplex_register.fs')),'qualified_bundle_fs_sha256':sha(qualified.read('duplex_register.fs'))}
assert len(set(result['baseline_bundles_same_fs'].values()))==1
result['baseline_bundle_correction']='Source/constraints/17of18 comparison uses duplex-register candidate.zip; aggregate resources use communication-qualified qualified-gfx-7375.zip. Same FS SHA verified; prior missing-report assertion was bundle mix-up.'
(out/'build-review.json').write_text(json.dumps(result,indent=2))
(out/'build-review.log').write_text(json.dumps({k:result[k] for k in ['offline_checks_pass','usercode','fs_sha256','sta_counts','fmax','minima','resources','baseline_resources','resource_delta_used','baseline_resource_report','baseline_bundles_same_fs','baseline_bundle_correction','changed_sources','nondepth_same','all_cst_locations_match','warnings_extra_vs7375','errors']},indent=2))
print('corrected baseline resources',baseline_resources,'delta',result['resource_delta_used'])
