from pathlib import Path
import hashlib,json,zipfile,subprocess,shutil
root=Path(__file__).resolve().parent
repo=Path('D:/github/airpocket-soundman/tab5-carrier-review-20261106')
dest=repo/'fpga/validation/depth16-2026-11-06';dest.mkdir(parents=True,exist_ok=True)
build=repo/'fpga/build/depth16-v1';pnr=build/'depth16/impl/pnr'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
inputs=[]
for p in sorted((build/'source_snapshot').rglob('*')):
 if p.is_file():
  rel=p.relative_to(build/'source_snapshot');assert sha(p)==sha(repo/'fpga'/rel),str(rel)
  inputs.append(dict(path='fpga/'+rel.as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
assert len(inputs)==18
assert sha(pnr/'depth16.fs')=='b2e4030294768e7f3a73922ceec7cebcd800c8b09c5aa4bfb80ffbf155b64f49'
required=['baseline-before-retry','depth16-bench','baseline-after','depth16-bench-after','depth16-quick','depth16-images36','depth16-other7','depth16-runtime-abba','depth16-live','program-depth16','restore-baseline','reload-depth16']
for name in required:assert json.loads((root/name/'result.json').read_text())['passed'],name
assert json.loads((root/'rtl-all.json').read_text())['status']=='passed'
review=json.loads((root/'build-review.json').read_text());assert review['build_completed']
with zipfile.ZipFile(dest/'candidate.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 z.write(pnr/'depth16.fs','depth16.fs')
 for p in sorted(pnr.glob('*')):
  if p.is_file() and p.suffix in {'.html','.txt','.sdf','.vo','.log'}:z.write(p,'pnr/'+p.name)
 for p in sorted((build/'source_snapshot').rglob('*')):
  if p.is_file():z.write(p,p.relative_to(build))
 z.write(repo/'fpga/builds/dock/build_depth16.tcl','build_depth16.tcl')
with zipfile.ZipFile(dest/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=1)as z:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix in {'.json','.log','.py','.png','.gz','.csv'}:z.write(p,p.relative_to(root))
 for p in sorted((repo/'fpga/build/depth16-review').glob('*')):
  if p.is_file() and p.suffix in {'.json','.log','.mem','.v'}:z.write(p,'depth16-miter/'+p.name)
for name in ['performance-summary.json','build-review.json','rtl-all.json']:shutil.copy2(root/name,dest/name)
files=[dest/'candidate.zip',dest/'evidence.zip',dest/'performance-summary.json',dest/'build-review.json',dest/'rtl-all.json']
manifest=dict(firmware_source_commit=subprocess.check_output(['git','rev-parse','3fe0e33'],cwd=repo,text=True).strip(),source_inputs=inputs,fs_sha256=sha(pnr/'depth16.fs'),usercode='000016D0',baseline_fs_sha256='4aaac60cf35ec9effa1eb48aec657c8d29c9ea18655eca7c0d20a0667af8427b',host_elf_sha256='4d9b6dd2c9dd232e0b50d8899267d67e5140bf9674a3cc993f7b4be5dd707ef6',core_mhz=54,sampler_mhz=216,tx_hz=20000000,rx_hz=16000000,hardware_programmed_and_tested=True,files=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p))for p in files])
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Source inputs verified',len(inputs),'public bytes',sum(p.stat().st_size for p in files))
