from pathlib import Path
import argparse,sys,json,hashlib,subprocess,re
repo=Path('D:/github/airpocket-soundman/tab5-gpu-review-20261106');sys.path.insert(0,str(repo/'tools'))
from gpu_lab import Client
from compare_all_scenes import verify_target
from compare_dock_demo import wait_idle
from qualify_demo_profile import info_guard,profile
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--fs',type=Path,required=True);p.add_argument('--sha',required=True);p.add_argument('--usercode',required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
r={'passed':False};prog=Path('D:/tools/gowin-programmer-1.9.12.04/Programmer/bin/programmer_cli.exe')
def operation(op,label,fs=None):
 cmd=[str(prog),'--device','GW2A-18C','--operation_index',str(op),'--cable-index','1','--frequency','2.5MHz']
 if fs:cmd+=['--fsFile',str(fs)]
 t=subprocess.run(cmd,cwd=prog.parent,capture_output=True,text=True);(a.output/(label+'.log')).write_text(t.stdout+t.stderr);r[label]=dict(exit_code=t.returncode,output=t.stdout+t.stderr)
 return t.stdout+t.stderr
def code(text,label):
 m=re.search(label+r' is:\s*0x([0-9A-Fa-f]+)',text);assert m,text;return int(m[1],16)
try:
 r['target']=verify_target('COM4');r['fs_sha256']=hashlib.sha256(a.fs.read_bytes()).hexdigest();assert r['fs_sha256']==a.sha.lower()
 r['fs_path']=str(a.fs);c=Client('COM4',timeout=30)
 try:
  r['info']=c.call('info');info_guard(r['info'],'4d9b6dd2c9dd232e0b50d8899267d67e5140bf9674a3cc993f7b4be5dd707ef6')
  c.call('stop');wait_idle(c,timeout=20);r['disarmed']=c.call('link',action='disarm');profile(r['disarmed'],False,r['info']['boot_id'],fast_pack=False,tx_hz=20000000)
 finally:c.close()
 prior=code(operation(73,'before-usercode'),'User Code');assert prior in (0x7375,0x16d0)
 assert code(operation(74,'before-status'),'Status Code')==0x6020
 operation(2,'program-sram',a.fs)
 assert code(operation(73,'after-usercode'),'User Code')==int(a.usercode,16)
 assert code(operation(74,'after-status'),'Status Code')==0x6020
 r['passed']=True
except Exception as e:r['error']=repr(e)
(a.output/'result.json').write_text(json.dumps(r,indent=2)+'\n');print('PASS',r['passed'],r.get('error'),flush=True);sys.exit(0 if r['passed']else 1)
