from pathlib import Path
import json,sys,gzip,hashlib,subprocess,re
repo=Path('D:/github/airpocket-soundman/tab5-gpu-review-20261106');sys.path.insert(0,str(repo/'tools'))
from gpu_lab import Client
from compare_all_scenes import verify_target
from compare_dock_demo import render_one,compare_raw,wait_idle,write_frame
from qualify_demo_profile import info_guard,profile,account
from bench_polygon_demos import checked
root=Path(__file__).resolve().parent;out=root/'depth16-images36';out.mkdir(exist_ok=False);(out/'images').mkdir()
sha='4d9b6dd2c9dd232e0b50d8899267d67e5140bf9674a3cc993f7b4be5dd707ef6'
r={'passed':False,'expected_elf_sha':sha,'cases':[],'scope':'New FPGA images vs previously captured CPU integer RGB565 from identical host ELF/geometry; CPU raw SHA verified, full bytes compared. CPU is NOT re-rendered in this run. Fixed20/16 bytewise queueON RXoptsOFF.'}
def save():(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def jtag():
 p=Path('D:/tools/gowin-programmer-1.9.12.04/Programmer/bin/programmer_cli.exe');text=subprocess.check_output([str(p),'--device','GW2A-18C','--operation_index','73','--cable-index','1','--frequency','2.5MHz'],cwd=p.parent,text=True)
 assert re.search(r'User Code is:\s*0x000016[dD]0',text),text
 return text
c=None
try:
 refs=[]
 for name in ['polygon9','polygon27']:
  f=Path('D:/esp/images/polygon-optimization-20261106/precomputed-bins')/name/'result.json';d=json.loads(f.read_text());assert d['passed'] and d['expected_elf_sha']==sha
  for case in d['cases']:
   assert case['passed'];refs.append((f,case))
 assert len(refs)==36
 r['target']=verify_target('COM4');r['jtag_before']=jtag();c=Client('COM4',timeout=60)
 r['info']=c.call('info');info_guard(r['info'],sha);boot=r['info']['boot_id'];c.call('stop');wait_idle(c,boot,30)
 s=c.call('link',action='status');checked(s,boot,s['link_armed']);assert not s['dma_opt_zero_copy_view'] and not s['dma_opt_reuse_stream_crc']
 if not s['link_armed']:checked(c.call('link',action='arm'),boot,True)
 for number,(source,ref) in enumerate(refs):
  demo=ref.get('polygon_demo','cubes');load=ref['load'];frame=ref['frame'];cpu=ref['CPU'];meta=cpu['capture'];assert meta['mode']=='CPU' and meta['raster']=='integer_g0' and meta['polygon_demo']==demo
  path=Path(cpu['image_path']).with_suffix('.rgb565');gz=path.with_suffix('.rgb565.gz');raw=gzip.decompress(gz.read_bytes())if gz.exists()else path.read_bytes();assert hashlib.sha256(raw).hexdigest()==meta['sha256'];assert len(raw)==640*360*2
  before=c.call('link',action='status');checked(before,boot,True)
  gpu,capture,pixels=render_one(c,'FPGA',1,load,frame,boot,120,initial_poll_delay=3,polygon_demo=demo)
  after=c.call('link',action='status');checked(after,boot,True,demo,executed=True);assert after['link_errors']==before['link_errors']
  comparison=compare_raw(raw,pixels);point=dict(polygon_demo=demo,load=load,frame=frame,passed=comparison['exact_match'],reference_result=str(source),reference_cpu=cpu,FPGA=gpu,comparison=comparison,accounting=account(before,after,1));r['cases'].append(point)
  point['FPGA']['image_path']=write_frame(capture,pixels,out/'images'/f'{number:02d}-fpga')
  (out/'images'/f'{number:02d}-fpga.rgb565').unlink(missing_ok=True)
  (out/'images'/f'{number:02d}-fpga.rgb565.gz').write_bytes(gzip.compress(pixels));(out/'images'/f'{number:02d}-cpu-reference.rgb565.gz').write_bytes(gzip.compress(raw))
  save();assert comparison['exact_match'];print(number,demo,load,frame,'PASS',gpu['state']['render_ms'],flush=True)
 r['jtag_after']=jtag();r['passed']=True
except Exception as e:r['error']=repr(e)
finally:
 if c:
  try:c.call('stop');wait_idle(c,timeout=30);r['final_disarm']=c.call('link',action='disarm')
  except Exception as e:r['cleanup_error']=repr(e);r['passed']=False
  c.close()
 save()
print('PASS',r['passed'],r.get('error'),flush=True);sys.exit(0 if r['passed']else 1)
