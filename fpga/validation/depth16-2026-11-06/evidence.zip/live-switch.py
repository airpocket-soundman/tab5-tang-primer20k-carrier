from pathlib import Path
import sys,json,time
repo=Path('D:/github/airpocket-soundman/tab5-gpu-review-20261106');sys.path.insert(0,str(repo/'tools'))
from gpu_lab import Client,save_capture
from compare_all_scenes import verify_target
from compare_dock_demo import wait_idle
from qualify_demo_profile import info_guard,profile
sha='4d9b6dd2c9dd232e0b50d8899267d67e5140bf9674a3cc993f7b4be5dd707ef6'
out=Path('D:/esp/images/depth16-20261106/depth16-live');out.mkdir(exist_ok=False)
r={'passed':False,'expected_elf_sha':sha,'transitions':[],'scope':'Live variant/mode/pause transitions with cooperative cancellation; pose ticks are not display FPS'}
def save():(out/'result.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
def checked(s,armed,boot):
 profile(s,armed,boot,fast_pack=False,tx_hz=20000000)
 assert s['polygon_queue_enabled'] is True
c=None
try:
 r['target']=verify_target('COM4');c=Client('COM4',timeout=30)
 r['info']=c.call('info');info_guard(r['info'],sha);boot=r['info']['boot_id']
 assert r['info']['polygon_live_tick_hz']==30
 c.call('stop');wait_idle(c,boot,20);c.call('link',action='disarm')
 c.call('link',action='polygon_queue',enabled=True)
 initial=c.call('link',action='arm');checked(initial,True,boot);errors=initial['link_errors']
 for mode,demo in [('FPGA','dancer'),('FPGA','robot'),('FPGA','city'),('CPU','robot'),('FPGA','robot')]:
  before=c.call('status')
  if before['running'] and before['mode']=='FPGA':
   deadline=time.monotonic()+3
   while not before['render_active'] and time.monotonic()<deadline:
    time.sleep(.02);before=c.call('status')
   assert before['render_active'],'No active GPU frame to exercise cancellation'
  point={'mode':mode,'polygon_demo':demo,'before':before};r['transitions'].append(point);save()
  point['selected']=c.configure(mode=mode,raster='integer_g0',scene=1,load=0,frame=0,polygon_demo=demo,running=True)
  base=point['selected']['completed_frames'];time.sleep(3)
  after=c.call('status');point['after']=after
  assert after['boot_id']==boot and after['running'] and after['mode']==mode and after['polygon_demo']==demo
  assert after['last_step_error']=='none' and after['completed_frames']>base and after['frame']>1
  point['passed']=True;save()
 c.call('stop');wait_idle(c,boot,20)
 stopped=c.call('link',action='status');checked(stopped,True,boot);assert stopped['link_errors']==errors
 r['paused_link']=stopped
 cap=c.call('capture',scope='viewport');assert cap['polygon_demo']=='robot' and cap['mode']=='FPGA'
 save_capture(cap,out/'robot-viewport.png')
 cap_ui=c.call('capture',scope='ui');save_capture(cap_ui,out/'robot-ui.png')
 r['capture']={k:v for k,v in cap.items()if k!='pixels_base64'}
 r['capture_ui']={k:v for k,v in cap_ui.items()if k!='pixels_base64'}
 c.configure(mode='FPGA',raster='integer_g0',scene=1,load=0,polygon_demo='robot',running=True)
 time.sleep(3);r['final_live']=c.call('status')
 assert r['final_live']['running'] and r['final_live']['last_step_error']=='none'
 r['passed']=True
except Exception as e:
 r['error']=repr(e)
 if c:
  try:c.call('stop');wait_idle(c,timeout=20);r['failure_disarm']=c.call('link',action='disarm')
  except Exception as cleanup:r['cleanup_error']=repr(cleanup)
finally:
 save()
 if c:c.close()
print(json.dumps({'passed':r['passed'],'error':r.get('error')}),flush=True)
sys.exit(0 if r['passed']else 1)
