
`timescale 1ns/1ps
module tb_conv_tile;
 reg clk=0,reset=1,abort=0,load_start=0,start=0;
 reg [4:0] cfg_ic=0,cfg_oh=0,cfg_ow=0;reg[3:0]cfg_oc=0;
 reg[1:0]cfg_kernel=0,cfg_stride=0;reg[5:0]cfg_input_h=0,cfg_input_w=0;
 reg first_block=0,final_block=0,upload_valid=0,upload_kind=0;
 reg[14:0]upload_address=0;reg signed[7:0]upload_data=0;
 wire upload_ready,busy,block_done,output_valid,error;wire[2:0]error_code;wire[31:0]compute_cycles;
 reg read_enable=0;reg[10:0]read_address=0;wire read_valid;wire signed[31:0]read_data;
 integer f,rc,jobs,j,i,ni,nw,no,v,first,last,ci,co,ho,wo,k,s,hi,wi,expected_cycles,timeout,expected_error;
 reg signed[31:0]expected[0:2047];
 always #5 clk=~clk;
 conv_tile_engine dut(.*);
 task tick;begin @(posedge clk);#1;end endtask
 task clear;begin @(negedge clk);abort=1;tick();@(negedge clk);abort=0;tick();if(error || busy || output_valid || read_valid)$fatal(1,"abort failed");end endtask
 task pulse_load;begin @(negedge clk);load_start=1;tick();@(negedge clk);load_start=0;end endtask
 task put;input integer kind,address,value;
 begin @(negedge clk);upload_kind=kind;upload_address=address;upload_data=value;upload_valid=1;
 if(!upload_ready)$fatal(1,"upload not ready");tick();@(negedge clk);upload_valid=0;end endtask
 task launch;begin @(negedge clk);start=1;tick();@(negedge clk);start=0;end endtask
 task wait_done;
 begin timeout=0;while(!block_done && !error && timeout<1000000)begin tick();timeout=timeout+1;end
 if(!block_done || error)$fatal(1,"compute failed job %d status %d timeout %d",j,error_code,timeout);
 end endtask
 task get;input integer address,value;
 begin @(negedge clk);read_address=address;read_enable=1;tick();
 if(!read_valid || read_data!==value)$fatal(1,"read mismatch job %d word %d got %d expected %d",j,address,read_data,value);
 @(negedge clk);read_enable=0;tick();if(read_valid || read_data!==0)$fatal(1,"read publication leaked");end endtask
 initial begin
 tick();tick();@(negedge clk);reset=0;tick();
 f=$fopen("D:/GitHub/airpocket-soundman/tab5-tang-primer20k-carrier-resume-20261106/fpga/build/conv-tile-fault-full/vectors.txt","r");if(!f)$fatal(1,"vectors unavailable");rc=$fscanf(f,"%d",jobs);
 for(j=0;j<jobs;j=j+1)begin
 rc=$fscanf(f,"%d %d %d %d %d %d %d %d %d %d %d",ci,co,ho,wo,k,s,first,last,ni,nw,expected_error);if(rc!=11)$fatal(1,"bad header %d",j);
 hi=(ho-1)*s+k;wi=(wo-1)*s+k;no=co*ho*wo;
 @(negedge clk);cfg_ic=ci;cfg_oc=co;cfg_oh=ho;cfg_ow=wo;cfg_kernel=k;cfg_stride=s;cfg_input_h=hi;cfg_input_w=wi;first_block=first;final_block=last;
 pulse_load();if(error || output_valid)$fatal(1,"load failed %d",j);
 // Config is latched at load_start, not read later during upload/compute.
 cfg_ic=0;cfg_oc=0;cfg_oh=0;cfg_ow=0;cfg_kernel=0;cfg_stride=0;cfg_input_h=0;cfg_input_w=0;first_block=0;final_block=0;
 for(i=0;i<ni;i=i+1)begin rc=$fscanf(f,"%d",v);if(rc!=1)$fatal(1,"missing input");put(0,i,v);end
 for(i=0;i<nw;i=i+1)begin rc=$fscanf(f,"%d",v);if(rc!=1)$fatal(1,"missing weight");put(1,i,v);end
 if(last && !expected_error)for(i=0;i<no;i=i+1)begin rc=$fscanf(f,"%d",expected[i]);if(rc!=1)$fatal(1,"missing oracle");end
 launch();
 if(expected_error)begin
 timeout=0;while(!error && timeout<1000000)begin tick();timeout=timeout+1;end
 if(!error || error_code!=expected_error || output_valid || read_valid || read_data!==0)$fatal(1,"real accumulated overflow not rejected");clear();
 end else begin
 wait_done();
 expected_cycles=no*(2*ci*k*k+3);if(compute_cycles!==expected_cycles)$fatal(1,"cycle counter job %d got %d expected %d",j,compute_cycles,expected_cycles);
 if(output_valid!==last[0])$fatal(1,"partial result published %d",j);
 if(last)for(i=0;i<no;i=i+1)get(i,expected[i]);
 end
 end
 $fclose(f);
 // Invalid configurations, missing data, sequential upload, invalid reads.
 clear();cfg_ic=1;cfg_oc=1;cfg_oh=1;cfg_ow=1;cfg_kernel=2;cfg_stride=1;cfg_input_h=2;cfg_input_w=2;first_block=1;final_block=1;pulse_load();if(!error || error_code!=1)$fatal(1,"bad kernel accepted");
 clear();cfg_kernel=1;cfg_input_h=1;cfg_input_w=1;pulse_load();launch();if(!error || error_code!=2)$fatal(1,"missing data accepted");
 clear();pulse_load();put(0,1,3);if(!error || error_code!=2)$fatal(1,"upload hole accepted");
 clear();pulse_load();put(0,0,3);put(0,0,4);if(!error || error_code!=2)$fatal(1,"duplicate upload accepted");
 clear();first_block=0;pulse_load();if(!error || error_code!=4)$fatal(1,"no partial accepted");
 clear();@(negedge clk);read_enable=1;tick();if(!error || error_code!=4 || read_valid || read_data!==0)$fatal(1,"invalid read published");@(negedge clk);read_enable=0;
 // Abort during a nonfinal tile discards partial output and clears faults.
 clear();cfg_ic=1;cfg_oc=1;cfg_oh=1;cfg_ow=1;cfg_kernel=1;cfg_stride=1;cfg_input_h=1;cfg_input_w=1;first_block=1;final_block=0;pulse_load();put(0,0,-128);put(1,0,127);launch();tick();clear();first_block=0;pulse_load();if(!error || error_code!=4)$fatal(1,"aborted partial reused");
 // Force a 32-bit boundary only as a fault-injection test. No successful
 // numerical comparison relies on internal state or this injected value.
 clear();first_block=1;final_block=0;pulse_load();put(0,0,127);put(1,0,127);launch();wait_done();
 dut.output_memory[0]=32'sh7fffffff;first_block=0;final_block=1;pulse_load();put(0,0,1);put(1,0,1);launch();timeout=0;while(!error && timeout<100)begin tick();timeout=timeout+1;end
 if(!error || error_code!=3 || output_valid || read_valid || read_data!==0)$fatal(1,"overflow exposed output");clear();
 // Start/load during active compute is rejected and invalidates partials.
 first_block=1;final_block=1;pulse_load();put(0,0,1);put(1,0,1);launch();launch();if(!error || error_code!=4 || output_valid)$fatal(1,"busy start accepted");clear();
 $display("PASS conv_tile jobs=%0d independent INT64, maximum shapes, partial IC blocks, latch/holes/abort/overflow",jobs);$finish;
 end
 initial begin #2000000000;$fatal(1,"global timeout");end
endmodule
