import sys,json,time,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'tools'))
from gpu_lab import Client
from compare_dock_demo import wait_idle
from compare_all_scenes import verify_target
out=pathlib.Path(sys.argv[1]);out.mkdir(exist_ok=False);d={'passed':False,'requested':1000,'count':64,'tx_hz':20000000,'rx_hz':16000000,'fast_pack':False,'points':[]};c=Client('COM4')
try:
 d['usb']=verify_target('COM4');d['info']=c.call('info');assert d['info']['elf_sha256']=='b841dec7ae6a09d971128d50484cc4ac8250d8892713698c2199ec67ceb760b0';c.call('stop');wait_idle(c);c.call('link',action='disarm');c.call('link',action='tx_phase',phase='positive');c.call('link',action='tx_mode',mode='persistent_dma',freq_hz=20000000);c.call('link',action='tx_fast_pack',enabled=False);d['before']=c.call('link',action='arm');assert d['before']['dma_rx_freq_hz']==16000000;t=time.monotonic()
 for n in range(1000):
  s=c.call('link',action='tx_batch_probe',count=64)
  if (n+1)%50==0:
   q={'completed':n+1,'elapsed_s':time.monotonic()-t,'verified_words':s['batch_probe_verified_words']-d['before']['batch_probe_verified_words'],'link_errors':s['link_errors']-d['before']['link_errors']};d['points'].append(q);(out/'result.json').write_text(json.dumps(d,indent=2),encoding='utf-8');print(q,flush=True)
 d['after']=s;assert s['batch_probe_count']-d['before']['batch_probe_count']==1000;assert s['batch_probe_verified_words']-d['before']['batch_probe_verified_words']==2048000;assert s['link_errors']==d['before']['link_errors'];d['passed']=True
except Exception as e:d['error']=str(e);print(e)
finally:
 try:c.call('stop');wait_idle(c);d['final_status']=c.call('link',action='disarm')
 except Exception as e:d['cleanup_error']=str(e);d['passed']=False
 c.close();(out/'result.json').write_text(json.dumps(d,indent=2),encoding='utf-8');print('passed',d['passed'])
