"""Root SRAM-only trial for frozen combined filtered GFX image. Plan default."""
import argparse,datetime,gzip,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
TOOL=Path('D:/github/airpocket-soundman/tab5-tang-primer20k-carrier/fpga/build/tools/gowin-programmer-1.9.12.04/Programmer/bin/programmer_cli.exe')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--confirm-software-disarmed',action='store_true');a=p.parse_args()
 directory=ROOT/'fpga/validation/clock-filter-qualified-2026-11-04';manifest=directory/'manifest.json';m=json.loads(manifest.read_bytes())
 assert m['source_commit']=='255e5da5a71b551ecb055bdb035dfe0ba433d85d' and m['no_timing_waivers']
 assert m['sta_summary']['Numbers of Setup Violated Endpoints']==m['sta_summary']['Numbers of Hold Violated Endpoints']==0
 assert set(m['actual_clock_domains'])=={'core54','sampler216','conditioned_reply54'}
 assert all(c['actual_fmax_mhz']>=c['target_mhz']for c in m['actual_clock_domains'].values())
 for name,expected in m['source_sha256'].items():assert sha(ROOT/'fpga'/name)==expected,name
 image=None
 for r in m['artifacts']:
  archived=directory/r['archived'];assert sha(archived)==r['gzip_sha256'];assert hashlib.sha256(gzip.decompress(archived.read_bytes())).hexdigest()==r['sha256']
  path=Path(r['source']);assert sha(path)==r['sha256'],str(path)
  if path.suffix=='.fs':image=path
 assert image and sha(image)=='6c5a10f5c298bc78a8c73bd455247e7f1ea9278880ef055fb8e15d867146658e'
 fs=image.read_text();code=int(re.search(r'//UserCode: 0x([0-9A-Fa-f]+)',fs).group(1),16)
 footer=[s for s in fs.splitlines()if len(s)==64 and s.startswith('00001010')];assert len(footer)==1 and int(footer[0][-32:],2)==code==0x7d1f
 record={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'SRAM-only combinedfilter/vendorRAM/pipeline/localreset; not filter-only attribution','image_sha256':sha(image),'expected_usercode':'0x00007d1f','manifest_sha256':sha(manifest),'source_sha256':m['source_sha256'],'programmer_sha256':sha(TOOL),'root_review':'two independent peers reran models/CPUoracle/ownership/stoppedclock control and actual3-domainSTA; IO delay/analog unqualified','operations':[]}
 commands=[]
 for op in (2,74,73):
  cmd=[str(TOOL),'--device','GW2A-18C','--operation_index',str(op),'--cable-index','4','--location','98609','--frequency','2.5MHz']
  if op==2:cmd+=['--fsFile',str(image)]
  commands.append((op,cmd))
 if not a.execute:print(json.dumps(dict(record,commands=commands),indent=2));return 0
 assert a.confirm_software_disarmed
 out=ROOT/'fpga/build/programming-clockfilter'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ');out.mkdir(parents=True)
 for op,cmd in commands:
  done=subprocess.run(cmd,capture_output=True,text=True,errors='replace');log=out/f'op{op}.log';log.write_text(done.stdout+done.stderr,encoding='utf8');record['operations'].append(dict(op=op,exit_code=done.returncode,log_sha256=sha(log)));print('operation',op,'exit',done.returncode,(done.stdout+done.stderr)[-450:])
 record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['programmer_all_operations_succeeded']=all(r['exit_code']==0 for r in record['operations']);record['independent_identity_match']='0x00006020' in (out/'op74.log').read_text() and '0x00007D1F' in (out/'op73.log').read_text()
 (out/'programming.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print('record',out/'programming.json');return 0 if record['programmer_all_operations_succeeded']else 1
if __name__=='__main__':raise SystemExit(main())
