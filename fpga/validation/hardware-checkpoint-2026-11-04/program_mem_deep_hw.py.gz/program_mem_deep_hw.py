"""Root-only SRAM MEM trial; plan by default. Preserves programmer errors."""
import argparse,datetime,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
PROGRAMMER=Path('D:/github/airpocket-soundman/tab5-tang-primer20k-carrier/fpga/build/tools/gowin-programmer-1.9.12.04/Programmer/bin/programmer_cli.exe')
FS_SHA='dbcd88fdc3d12fead7f5de9bd653866d5fbe4ec7eb9a3bd8f71cf4dcb088844b'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--confirm-software-disarmed',action='store_true');a=p.parse_args()
 manifest=ROOT/'fpga/validation/mem-deep-diag-prehardware-2026-11-04.json';m=json.loads(manifest.read_bytes())
 assert m['sta_constraints_pass'] and m['pin_audit']['passed']
 assert m['setup_violated_endpoints']==0 and m['hold_violated_endpoints']==0
 for k in ('remaining_negative_recovery_paths','remaining_negative_hold_paths','remaining_negative_setup_paths','remaining_negative_removal_paths'):assert not m[k],k
 assert m['configured_bytes']==134217728 and m['memory_hz']==324000000 and m['user_hz']==81000000
 inputs={}
 for f in m['inputs']+m['outputs']:
  target=ROOT/'fpga'/f['path'];assert sha(target)==f['sha256'],str(target);inputs[str(target)]=f['sha256']
 image=ROOT/'fpga/build/mem-deep-diag/mem_bist/impl/pnr/mem_bist.fs';assert sha(image)==FS_SHA
 code=int(re.search(r'//UserCode: 0x([0-9A-Fa-f]+)',image.read_text()).group(1),16);assert code==0x0f25
 assert PROGRAMMER.is_file()
 commands=[]
 for op in (2,74,73):
  command=[str(PROGRAMMER),'--device','GW2A-18C','--operation_index',str(op),'--cable-index','4','--location','98609','--frequency','2.5MHz']
  if op==2:command+=['--fsFile',str(image)]
  commands.append((op,command))
 record=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='SRAM-only native-diagnostic MEM first64-beat hardware trial; runtime014f required; physical DDR unverified; no SPI flash',root_review='configuration/pin/source/STA guarded90vendorinputs checked; no owned reset exception; runtime qualification required',image_sha256=FS_SHA,expected_usercode='0x00000f25',manifest_sha256=sha(manifest),inputs_outputs_sha256=inputs,programmer_sha256=sha(PROGRAMMER),software_disarmed_declared=a.confirm_software_disarmed,operations=[])
 if not a.execute:print(json.dumps(dict(record,commands=commands),indent=2));return 0
 assert a.confirm_software_disarmed
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ');out=ROOT/'fpga/build/programming-mem-deep'/stamp;out.mkdir(parents=True)
 for op,command in commands:
  done=subprocess.run(command,capture_output=True,text=True,errors='replace');log=out/f'op{op}.log';log.write_text(done.stdout+done.stderr,encoding='utf8');record['operations'].append(dict(op=op,exit_code=done.returncode,log=str(log),log_sha256=sha(log)));print('operation',op,'exit',done.returncode,(done.stdout+done.stderr)[-500:])
 record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 record['programmer_all_operations_succeeded']=all(x['exit_code']==0 for x in record['operations'])
 record['independent_status_usercode_match']=('0x00006020' in (out/'op74.log').read_text() and '0x00000F25' in (out/'op73.log').read_text().upper().replace('0X','0x'))
 (out/'programming.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print('record',out/'programming.json')
 return 0 if record['programmer_all_operations_succeeded'] else 1
if __name__=='__main__':raise SystemExit(main())
